<?php wp_footer(); ?>     
      <!-- footer -->
      <footer class="footer layout_padding">
         <div class="container">
            <div class="row">

               <div class="col-md-4 col-sm-12">
                  <!-- Add custom sidebar -->
                  <?php 
                  if(is_active_sidebar( 'sidebar-2' )) :
                     dynamic_sidebar( 'sidebar-2' );
                  endif;
                  ?>
               </div>
               
               <div class="col-md-8">
                 <div class="row">
                    <div class="col-md-4 col-sm-12">
                  <div class="footer_link_heading">
                     <h3>FEATURED COURSES</h3>
                  </div>
                  <div class="footer_menu">
                     <!-- create footer menu 1 -->
                     <?php
                        wp_nav_menu( $args = array(
                           'theme_location'  => 'footer_one',
                           'menu_id'         => 'footer-menu',
                           'depth'           => 1,
                        ) );
                     ?>
                     <!-- <ul>
                        <li><a href="#">Starting Soon</a></li>
                        <li><a href="#">Just Added</a></li>
                        <li><a href="#">Most Viewed</a></li>
                        <li><a href="#">Top Paid</a></li>
                     </ul> -->
                  </div>
               </div>

               <div class="col-md-4 col-sm-12">
                  <div class="footer_link_heading">
                     <h3>CATEGORIES</h3>
                  </div>
                  <div class="footer_menu">
                     <!-- create footer menu 2 -->
                     <?php
                        wp_nav_menu( $args = array(
                           'theme_location'  => 'footer_two',
                           'menu_id'         => 'footer-menu',
                           'depth'           => 1,
                        ) );
                     ?>
                    <!-- <ul>
                       <li><a href="#">Arts & Design</a></li>
                       <li><a href="#">Business</a></li>
                       <li><a href="#">Computer</a></li>
                       <li><a href="#">Data entery</a></li>
                    </ul> -->
                  </div>
               </div>
               
               <div class="col-md-4 col-sm-12">
                  <div class="footer_link_heading">
                     <h3>USEFUL LINKS</h3>
                  </div>
                  <div class="footer_menu">
                     <!-- create footer menu 3 -->
                     <?php
                        wp_nav_menu( $args = array(
                           'theme_location'  => 'footer_three',
                           'menu_id'         => 'footer-menu',
                           'depth'           => 1,
                        ) );
                     ?>
                    <!-- <ul>
                       <li><a href="#">FAQs</a></li>
                       <li><a href="#">Success Stories</a></li>
                       <li><a href="#">Shop</a></li>
                       <li><a href="#">Privacy policy</a></li>
                       <li><a href="#">Contact search</a></li>
                       <li><a href="#">Jobs and vacancies</a></li>
                    </ul> -->
                  </div>
               </div>
                 </div>
               </div>
               
            </div>
         </div>
      </footer>
      <div class="cpy">
        <div class="container">
           <div class="row">
             <div class="col-md-12">
             <?php
               if(is_active_sidebar( 'sidebar-5' )):
                  dynamic_sidebar( 'sidebar-5' );
               endif;
             ?>
               <!-- <p>&copy; Copyright <script>document.write(new Date().getFullYear())</script>. All Rights Reserved.</p> -->
             </div>
           </div>
        </div>
      </div>
      <!-- end footer -->
      <!-- Core JavaScript
         ================================================== -->
      <!-- <script src="js/jquery.min.js"></script> -->
      <!-- <script src="js/tether.min.js"></script> -->
      <!-- <script src="js/bootstrap.min.js"></script> -->
      <!-- <script src="js/parallax.js"></script> -->
      <!-- <script src="js/animate.js"></script> -->
      <!-- <script src="js/ekko-lightbox.js"></script> -->
      <!-- <script src="js/custom.js"></script> -->
   </body>
</html>
