<?php
/**
 * Template Name: Home
 */
?>
<?php get_header(); ?>
      <!-- section -->
      <section class="main_full banner_section_top">
        <div class="container-fluid">
          <div class="row">
             <div class="full">
                  <div class="slider_banner">
                  <?php
                     if(is_active_sidebar( 'banner-sidebar' )) :
                        dynamic_sidebar( 'banner-sidebar' );
                     endif;
                  ?>
                    <!-- <img class="img-responsive" src="<?php // bloginfo( "template_url" ); ?>/images/slider_img.png" alt="#" />
                      <div class="slide_cont">
                        <div class="slider_cont_inner">
                          <h3>Welcome To Our  Web Coaching</h3>
                           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit</p>
                        </div>
                      </div> -->
                  </div>
                </div>
          </div>
        </div>
      </section>
      <!-- end section -->
  
     <!-- about section -->
     
     <?php
     /* Get content from one page and show it on another page */ 
     
     $args = array( 'post_type' => 'page','page_id' => 10 );
     $the_query = new WP_Query( $args );
     while ( $the_query->have_posts() ) :      
     $the_query->the_post();
     ?>
      <div class="container-fluid">
         <div class="row">
            <div class="full">
            <h3 class="page-title"><?php the_title(); ?></h3>    
            </div>
         </div>
      </div>
      <?php
     the_content();
     endwhile;
     wp_reset_postdata();
     
     ?>
     <?php // get_template_part( 'template', 'about' ); ?>
      <!-- <section class="layout_padding section about_dottat">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 text_align_center">
                  <div class="full heading_s1">
                     <h2>About</h2>
                  </div>
                  <div class="full">
                     <p class="large">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="about_img margin_top_30  text_align_center">
                     <img src="<?php bloginfo( "template_url" ); ?>/images/ab_img.png" alt="#" />
                  </div>
               </div>
            </div>
         </div>
      </section> -->
      <!-- end about section -->
<!-- Coaching Start -->
      <!-- section -->
      <?php
      /* Get content from one page and show it on another page */ 
     
     $args = array( 'post_type' => 'page','page_id' => 12 );
     $the_query = new WP_Query( $args );
     while ( $the_query->have_posts() ) :      
     $the_query->the_post();
     the_content();
     endwhile;
     wp_reset_postdata();
     ?>
      <!-- <section class="layout_padding section">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 text_align_center">
                  <div class="full heading_s1">
                     <h2>Our Courses</h2>
                  </div>
                  <div class="full">
                     <p class="large">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
                  </div>
               </div>
            </div>
            <div class="row">

              <div class="col-md-4 text_align_center">
                 <div class="cours">
                   <img class="img-responsive" src="<?php bloginfo( "template_url" ); ?>/images/cour1.png" alt="#" />
                 </div>
                 <h3>Design</h3>
                 <p>adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in re</p>
              </div>  

              <div class="col-md-4 text_align_center">
                 <div class="cours">
                   <img class="img-responsive" src="<?php bloginfo( "template_url" ); ?>/images/cour2.png" alt="#" />
                 </div>
                 <h3>Coding</h3>
                 <p>adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in re</p>
              </div> 

              <div class="col-md-4 text_align_center">
                 <div class="cours">
                   <img class="img-responsive" src="<?php bloginfo( "template_url" ); ?>/images/cour3.png" alt="#" />
                 </div>
                 <h3>Javascript</h3>
                 <p>adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in re</p>
              </div> 

            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="full center">
                      <a class="blue_bt" href="#">Read More</a>
                  </div>
               </div>
            </div>
         </div>
      </section> -->
      <!-- end section -->
<!-- Coaching end -->
<!-- Time Start -->
      <!-- section -->
      <?php
      /* Get content from one page and show it on another page */ 
     
     $args = array( 'post_type' => 'page','page_id' => 14 );
     $the_query = new WP_Query( $args );
     while ( $the_query->have_posts() ) :      
     $the_query->the_post();
     the_content();
     endwhile;
     wp_reset_postdata();
     
     ?>
      <!-- <section class="layout_padding section">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12 text_align_center">
                  <div class="full heading_s1">
                     <h2>Our Coaching Time</h2>
                  </div>
               </div>
            </div>
            <div class="row">
              <div class="col-md-12 cours_timging_bg">
                 <div class="container">
                    <div class="time_table">
                          <ul><li>Monday</li><li>8 Am - 6 Pm</li></ul>
                          <ul><li>Tuesday</li><li>9 Am - 5 Pm</li></ul>
                          <ul><li>Wednesday</li><li>10 Am - 8 Pm</li></ul>
                          <ul><li>Thursday</li><li>8  Am - 6 Pm</li></ul>
                          <ul><li>Friday</li><li>6 Am - 4 Pm</li></ul>
                          <ul><li>Saturday</li><li>9 Am - 5 Pm</li></ul>
                          <ul><li>Sunday</li><li>Holiday</li></ul>
                       </div>
                 </div>        
              </div> 
            </div>
         </div>
      </section> -->
      <!-- end section -->
<!-- Time Ends -->
<!-- News Letter Start -->
      <!-- section -->
      
      <section class="section blue_pattern_bg" style="background-color: #3b3bff;">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="full">
                     <?php
                     if (is_active_sidebar( 'sidebar-4' )) : 
                        dynamic_sidebar( 'sidebar-4' );
                     endif;
                     ?>
                  </div>
               </div>
               <div class="col-md-6">
               <?php echo do_shortcode('[contact-form-7 id="95" title="newsletter"]'); ?>
                 <!-- <div class="form_subribe">
                     <form>
                       <input type="email" name="email" placeholder="Enter Your Email" />
                       <button>Subscribe</button>
                    </form>
                 </div> -->
               </div>
            </div>
         </div>
      </section>
      <!-- end section -->

      <!-- News Letter End -->
      <?php get_footer(); ?>