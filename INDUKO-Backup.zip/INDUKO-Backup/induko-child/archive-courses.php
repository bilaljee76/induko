<?php
/**
 * Template Name: Courses List
*/
get_header();
?>
<!-- section -->
<section class="main_full inner_page">
    <div class="container-fluid">
        <div class="row">
            <div class="full">
            <!-- <h3 class="custom-page-title">Coaching</h3>     -->
            </div>
        </div>
    </div>
</section>
<!-- end section -->

</section>


<div class="container" id="blog-container">
    <div class="row">
    <?php
        $course_qry = new WP_Query( array(
            'post_type'         => 'courses',
            'posts_per_page'    => -1,  // display all post on one page (-1)
            'orderby'           => 'ID',
            'order'             => 'ASC',
            ) );
            if( $course_qry -> have_posts() ) :
                while( $course_qry->have_posts() ) : $course_qry->the_post();
    ?>
        <div class="col-md-12 col-sm-12">
            <h1 id="post-title"><a href="<?php echo get_post_permalink($post->ID); ?>"><?php the_title();?></a></h1>
        </div>
        <div class="col-md-12 col-sm-12">
            <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>
            <img id="feature-image" src="<?php echo $url; ?>" alt="" />
        </div>
        <div id="post-content" class="col-md-12 col-sm-12">
            <?php the_excerpt(); ?>
        </div>
        
        <?php endwhile; ?>
        
        <?php endif; ?>
        <?php wp_reset_query(); ?>
    </div><!-- /row -->
</div><!-- /Container -->


<?php get_footer(); ?>