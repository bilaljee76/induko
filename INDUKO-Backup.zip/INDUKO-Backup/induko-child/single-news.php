<?php
/**
 * Template Name: Single news
 */
?>

<?php get_header(); ?>

<!-- section -->
<section class="main_full inner_page">
    <div class="container-fluid">
        <div class="row">
            <div class="full">
            <!-- <h3 class="custom-page-title">Coaching</h3>     -->
            </div>
        </div>
    </div>
</section>
<!-- end section -->
<article id="post-news-<?php echo get_the_ID(); ?>" class="post-news">
<div class="container">
<?php 
if(have_posts() ) :
    while( have_posts() ) : the_post();
        the_title( "<h1>", "</h1>", true );
        the_content();
    endwhile;
endif;
?>
</div>
</article>


<?php get_footer(); ?>