<?php
/**
 * Template Name: About
 */
?>
<?php get_header(); ?>
<!-- About section -->
<section class="main_full inner_page">
   <div class="container-fluid">
      <div class="row">
         <div class="full">
         <h3>About us</h3>    
         </div>
      </div>
   </div>
</section>
<!-- end section -->
<?php
   /* Get content from wordpress page and show it on another page / in custom template */ 
     
     $args = array( 'post_type' => 'page','page_id' => 10 );
     $the_query = new WP_Query( $args );
     while ( $the_query->have_posts() ) :
     $the_query->the_post();
     the_content();
     endwhile;
     wp_reset_postdata();
     
?>
<!-- about section -->

<!-- end about section -->


<?php get_footer(); ?>