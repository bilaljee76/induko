<?php
/**
 * Template Name: Courses Detail
*/
get_header();
?>
<!-- section -->
<section class="main_full inner_page">
    <div class="container-fluid">
        <div class="row">
            <div class="full">
                <h3 class="custom-page-title">Courses</h3>    
            </div>
        </div>
    </div>
</section>
<!-- end section -->

</section>


<div class="container" id="blog-container">
    <div class="row">
        <?php
        $course_qry = new WP_Query( array(
            'post_type'         => 'courses', 
            'posts_per_page'    => 3,
            'orderby'           => 'ID',
            'order'             => 'ASC',
            ) );
            if( $course_qry -> have_posts() ) :
                while( $course_qry->have_posts() ) : $course_qry->the_post();
    ?>
        <div class="col-md-12 col-sm-12">
            <h1 id="post-title"><a href="<?php echo get_post_permalink($post->ID) ?>"><?php the_title();?></a></h1>
        </div>
        <div class="col-md-12 col-sm-12">
            <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>
            <img id="feature-image" src="<?php echo $url; ?>" alt="" />
        </div>

        <div id="post-content" class="col-md-12 col-sm-12">
            <?php $smallText = get_post_meta( get_the_ID(), 'induko_demo_textsmall', true ); ?>
            <?php $mediumText = get_post_meta( get_the_ID(), 'induko_demo_textmedium', true ); ?>
            <?php $indukoUrl = get_post_meta( get_the_ID(), 'induko_demo_url', true ); ?>
            <?php $induko_email = get_post_meta( get_the_ID(), 'induko_demo_email', true ); ?>
            <?php $induko_demo_time = get_post_meta( get_the_ID(), 'induko_demo_time', true ); ?>
            <?php $induko_timezone = get_post_meta( get_the_ID(), 'induko_demo_timezone', true ); ?>
            <?php $induko_textdate = get_post_meta( get_the_ID(), 'induko_demo_textdate', true ); ?>
            <?php $induko_textdate_timestamp = get_post_meta( get_the_ID(), 'induko_demo_textdate_timestamp', true ); ?>
            <?php $induko_datetime_timestamp = get_post_meta( get_the_ID(), 'induko_demo_datetime_timestamp', true ); ?>
            <?php $induko_textmoney = get_post_meta( get_the_ID(), 'induko_demo_textmoney', true ); ?>
            <?php $induko_colorpicker = get_post_meta( get_the_ID(), 'induko_demo_colorpicker', true ); ?>
            <?php $induko_textarea = get_post_meta( get_the_ID(), 'induko_demo_textarea', true ); ?>
            <?php $induko_textareasmall = get_post_meta( get_the_ID(), 'induko_demo_textareasmall', true ); ?>
            <?php $induko_textarea_code = get_post_meta( get_the_ID(), 'induko_demo_textarea_code', true ); ?>
            <?php $induko_select = get_post_meta( get_the_ID(), 'induko_demo_select', true ); ?>
            <?php $induko_radio_inline = get_post_meta( get_the_ID(), 'induko_demo_radio_inline', true ); ?>
            
            <!-- Taxonomy selection list -->
            <?php $induko_multicheckbox = get_post_meta( get_the_ID(), 'induko_demo_multicheckbox', true ); ?>
            

            <div class="metabox-wrapper">
                <?php echo "<div class='meta-text'><p class='meta-small-text'>".$smallText."</p></div>"; ?>
                <?php echo "<p>".$mediumText."</p>"; ?>
                <?php echo "<p>".$indukoUrl."</p>"; ?>
                <?php echo "<p>".$induko_email."</p>"; ?>
                <?php echo "<p>".$induko_demo_time."&nbsp;&nbsp;".$induko_timezone."</p>"; ?>
                <?php echo "<p>".$induko_timezone."</p>"; ?>
                <?php echo "<p>".$induko_textdate."</p>"; ?>
                <?php echo "<p>".$induko_textdate_timestamp."</p>"; ?>
                <?php echo "<p>".$induko_datetime_timestamp."</p>"; ?>
                <?php echo "<p>Rs.".$induko_textmoney."</p>"; ?>
                <?php echo "<p>".$induko_colorpicker."</p>"; ?>
                <?php echo "<p>".$induko_textarea."</p>"; ?>
                <?php echo "<p>".$induko_textareasmall."</p>"; ?>
                <?php echo "<p>".$induko_textarea_code."</p>"; ?>

                <?php 
                // selection option list display
                if ( 'standard' === $induko_select ) {
                    echo "<p>".$induko_select."</p>";
                }elseif('custom' === $induko_select) {
                    echo "<p>".$induko_select."</p>";
                }elseif('none' === $induko_select) {
                    echo "<p>".$induko_select."</p>";
                }else{
                    echo "<p>You are not select any option</p>";
                }
                ?>

                <?php 
                // radio inline option list display
                if ( 'Male' === $induko_radio_inline ) {
                    echo "<p>".$induko_radio_inline."</p>";
                }elseif('Female' === $induko_radio_inline) {
                    echo "<p>".$induko_radio_inline."</p>";
                }elseif('Shemale' === $induko_radio_inline) {
                    echo "<p>".$induko_radio_inline."</p>";
                }else{
                    echo "";
                }
                ?>
                
                <!-- Taxonomy radio -->
                <?php 
                $terms = get_terms( 'skills' );
                if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                    echo "<h1 id='post-title'>Taxonomy Below with italic style</h1>";
                    echo '<ul>';
                    foreach ( $terms as $term ) {
                        echo '<li><p><i>' . $term->name . '</i></p></li>';
                    }
                    echo '</ul>';
                }
                ?>
                
                <?php
                foreach($induko_multicheckbox as $multicheckbox){
                    echo "<p class='check-mark'> ".$multicheckbox."</p>";
                }
                ?>
                <!-- get wysiwyg editor content -->
                <?php
                $induko_wysiwyg = get_post_meta( get_the_ID(), 'induko_demo_wysiwyg', true );
                echo "<p>".$induko_wysiwyg."</p>";
                ?>
                
                <hr class="post-divider"><!-- post-divider -->

            </div>

        </div>

        <div id="post-content" class="col-md-12 col-sm-12">
            <?php the_excerpt(); ?>
        </div>

        <?php endwhile; ?>
        <!-- Simple Pagination -->
        <div id="paginate">
            <div class="prev-posts">
                <button><?php previous_post_link('%link', '&lt;&lt; Prev') ?></botton>
            </div>
            <div class="next-posts">
                <button><?php next_post_link('%link', 'Next &gt;&gt;') ?></botton>
            </div>
        </div>

        <?php endif; ?>
        <?php wp_reset_query(); ?>

    </div><!-- /row -->
</div><!-- /Container -->


<?php get_footer(); ?>