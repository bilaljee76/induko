<?php
/**
 * Template Name: Courses Tax
 */
get_header();

/** 
 *  Get the Custom Taxonomy
 *  For a list of other parameters to pass in see link below
 *  @link https://developer.wordpress.org/reference/classes/wp_term_query/__construct/
 *  For a list of get_term return values see link below
 *  @link https://codex.wordpress.org/Function_Reference/get_term
 * 
 */
?>
<section class="main_full inner_page">
   <div class="container-fluid">
      <div class="row">
         <div class="full">
         <!-- <h3>Contact</h3>     -->
         </div>
      </div>
   </div>
</section>

<div class="container tax-container">
<?php
$terms = get_terms( array(
        'taxonomy'      => 'skills',
        'hide_empty'    => false,
        'order'         => 'ASC',
));

echo '<ul>';

// Loop through all terms with a foreach loop
foreach( $terms as $term ) {
    // Use get_term_link to get terms permalink
    // USe $term->name to return term name
    echo '<li><h2  class="tex-title"><a href="'. get_term_link( $term ) .'">'. $term->name .'</a></h2></li>';
    
}

echo '</ul>';
?>
</div>
<?php get_footer(); ?>
