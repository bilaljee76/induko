<?php


if ( ! defined( 'DOMAIN' ) ) {
	// Replace the version number of the theme on each release.
	define( 'DOMAIN', 'induko' );
}


if ( ! defined( 'VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( 'VERSION', '1.0.0' );
}


add_action( 'wp_enqueue_scripts', 'induko_child_enqueue_styles' );
function induko_child_enqueue_styles() {

/*   
    $parenthandle = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.
    $theme = wp_get_theme();
    wp_enqueue_style( $parenthandle, get_template_directory_uri() . '/style.css', 
        array(),  // if the parent theme code has a dependency, copy it to here
        $theme->parent()->get('VERSION')
    );
    wp_enqueue_style( 'child-style', get_stylesheet_uri(),
        array( $parenthandle ),
        $theme->get('VERSION') // this only works if you have Version in the style header
    );
*/


/*
	// enqueue parent styles
	wp_enqueue_style('parent-theme', get_template_directory_uri() .'/style.css');
	
	// enqueue child styles
	wp_enqueue_style('child-theme', get_stylesheet_uri() .'/style.css', array('parent-theme') );
    
*/

/*    $deps = false;

	if (is_child_theme()) {
		
		$deps = array('parent-styles');
		
		// load parent styles if active child theme
		wp_enqueue_style('parent-styles', trailingslashit(get_template_directory_uri()) .'style.css', false);
		
	}
    // load active theme stylesheet
	wp_enqueue_style('theme-styles', get_stylesheet_uri(), $deps);
*/
    
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri(). '/style.css' );
    wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri(). '/css/bootstrap.css', 'VERSION', 'all');
    wp_enqueue_style( 'font-awesome', get_stylesheet_directory_uri(). '/css/font-awesome.min.css', 1, 'all' );
    wp_enqueue_style( 'animate', get_stylesheet_directory_uri(). '/css/animate.css', 'VERSION', 'all' );
    wp_enqueue_style( 'responsive', get_stylesheet_directory_uri(). '/css/responsive.css', 'VERSION', 'all' );
    wp_enqueue_style( 'colors', get_stylesheet_directory_uri(). '/css/colors.css', 'VERSION', 'all' );
    wp_enqueue_style( 'ekko-lightbox', get_stylesheet_directory_uri(). '/css/ekko-lightbox.css', 'VERSION', 'all' );

    wp_enqueue_style( 'editor-style', get_stylesheet_directory_uri(). '/assets/css/editor-style.css', 'VERSION', 'all' );
    wp_enqueue_style( 'Font_Awesome', 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' );
    // wp_enqueue_style('Font_Awesome');

        
    wp_enqueue_script( 'jquery', get_stylesheet_directory_uri(). '/js/jquery.min.js', array('jquery'), false, true );
    wp_enqueue_script( 'tether', get_stylesheet_directory_uri(). '/js/tether.min.js', array('jquery'), false, true );
    wp_enqueue_script( 'bootstrap', get_stylesheet_directory_uri(). '/js/bootstrap.min.js', array('jquery'), false, true );
    wp_enqueue_script( 'parallax', get_stylesheet_directory_uri(). '/js/parallax.js', array('jquery'), false, true );
    wp_enqueue_script( 'animate', get_stylesheet_directory_uri(). '/js/animate.js', array('jquery'), false, true );
    wp_enqueue_script( 'ekko-lightbox', get_stylesheet_directory_uri(). '/js/ekko-lightbox.js', array('jquery'), false, true );
    wp_enqueue_script( 'custom', get_stylesheet_directory_uri(). '/js/custom.js', array('jquery'), false, true );
}
    

// Theme Support Added Here

function induko_support_init() {
	// For Menu Support
	add_theme_support( 'menu' );
    
    // For Comments Link
	add_theme_support( 'automatic_feed_links' );

	// For HTML5 Support
	add_theme_support( 'html5', array( 'comment-link', 'comment-form', 'search-form', 'gallery', 'caption' ) );
	// Support for post format
	add_theme_support( 'post-formats', array( 'aside', 'gallery', 'video' ) );
    
    // For Custom Background
	$defualt_bg = array(
		'default-image'				=>	'',		// get_template_directory_uri() . '/images/background.jpg'
		'default-preset'     		=> 'default', // 'default', 'fill', 'fit', 'repeat', 'custom'
    	'default-position-x'     	=> 'left',    // 'left', 'center', 'right'
    	'default-position-y'     	=> 'top',     // 'top', 'center', 'bottom'
    	'default-size'           	=> 'auto',    // 'auto', 'contain', 'cover'
    	'default-repeat'         	=> 'no-repeat',  // 'repeat-x', 'repeat-y', 'repeat', 'no-repeat'
    	'default-attachment'    	=> 'fixed',  // 'scroll', 'fixed'
    	'default-color'          	=> '',
    	'admin-head-callback'    	=> '',
    	'admin-preview-callback' 	=> '',

	);
	add_theme_support( 'custom-background', $defualt_bg );

	// For custom Logo
	add_theme_support( 'custom_logo', array(
		'height' => 105,
		'width' => 277,
		'flex-height' => true,
		'flex-width' => true,
		'header-text' => array( 'site-title', 'site-description' ),
    ) );
    
	// For Post Thumbnail

	add_theme_support( 'post-thumbnails' );
	//the_post_thumbnail('post-thumbnail', ['class' => 'img-responsive responsive--full', 'title' => 'Feature image']);
	the_post_thumbnail( 'thumbnail');       // Thumbnail (default 150px x 150px max)
	the_post_thumbnail( 'medium' );          // Medium resolution (default 300px x 300px max)
	the_post_thumbnail( 'large' );           // Large resolution (default 640px x 640px max)
	the_post_thumbnail( 'full' );            // Full resolution (original size uploaded)
	add_image_size( 'custom-size', 220, 180 ); // 220 pixels wide by 180 pixels tall, soft proportional crop mode


	// Editor Styles
	add_theme_support( 'editor-styles' );

	// Turn on Wide images
	add_theme_support( 'align-wide' );

	// Block Color Palettes
	add_theme_support( 'editor-color-palette', array(
    array(
        'name' => __( 'strong magenta', 'DOMAIN' ),
        'slug' => 'strong-magenta',
        'color' => '#a156b4',
    ),
    array(
        'name' => __( 'light grayish magenta', 'DOMAIN' ),
        'slug' => 'light-grayish-magenta',
        'color' => '#d0a5db',
    ),
    array(
        'name' => __( 'very light gray', 'DOMAIN' ),
        'slug' => 'very-light-gray',
        'color' => '#eee',
    ),
    array(
        'name' => __( 'very dark gray', 'DOMAIN' ),
        'slug' => 'very-dark-gray',
        'color' => '#444',
    ),
	) );

	
	// Block Font Sizes
	add_theme_support( 'editor-font-sizes', array(
    array(
        'name' => __( 'Small', 'DOMAIN' ),
        'size' => 12,
        'slug' => 'small'
    ),
    array(
        'name' => __( 'Normal', 'DOMAIN' ),
        'size' => 16,
        'slug' => 'normal'
    ),
    array(
        'name' => __( 'Large', 'DOMAIN' ),
        'size' => 36,
        'slug' => 'large'
    ),
    array(
        'name' => __( 'Huge', 'DOMAIN' ),
        'size' => 50,
        'slug' => 'huge'
    )
    ) );



    // Custom header
	$defaults = array(
    	'default-image'          => '',
    	'random-default'         => false,
    	'width'                  => 0,
    	'height'                 => 0,
    	'flex-height'            => false,
    	'flex-width'             => false,
    	'default-text-color'     => '',
    	'header-text'            => true,
    	'uploads'                => true,
    	'wp-head-callback'       => '',
    	'admin-head-callback'    => '',
    	'admin-preview-callback' => '',
    	'video'                  => false,
    	'video-active-callback'  => 'is_front_page',
	);
	add_theme_support( 'custom-header', $defaults );


}
add_action( 'after_setup_theme','induko_support_init' );

/**End Theme Support Function/Hook */

// Induko Theme Menu Register Here

function register_induko_menu() {
	register_nav_menus( array(
		'top_menu'	    =>	__( 'Top Menu', 'DOMAIN' ),
        'sidebar_menu'  =>  __( 'Sidebar Menu', 'DOMAIN' ),
        'footer_one'	=>	__( 'Footer Left One', 'DOMAIN' ),
        'footer_two'	=>	__( 'Footer Left Two', 'DOMAIN' ),
        'footer_three'	=>	__( 'Footer Left Three', 'DOMAIN' ),
	) );	
}
add_action( 'after_setup_theme', 'register_induko_menu' );

// Make FILTER to add menu anchor class/classes in wordpress nav_menu
function add_additional_class_on_li($classes, $item, $args) {
    if(isset($args->add_li_class)) {
        $classes[] = $args->add_li_class;
    }
    return $classes;
}
add_filter('nav_menu_css_class', 'add_additional_class_on_li', 10, 3);

// Make FILTER to add menu anchor class/classes in wordpress nav_menu
function add_menu_achor_class( $atts, $item, $args ) {
    if(isset($args->add_anchor_class)) {
        $atts['class'] = $args->add_anchor_class;
    }
    return $atts;
    }
add_filter( 'nav_menu_link_attributes', 'add_menu_achor_class', 10, 3 );
/**End Theme Menu */


// Register Widgets

function induko_widgets_init() {
 
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'DOMAIN' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'The main sidebar appears on the right on each page except the front page template', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
 
    register_sidebar( array(
        'name'          =>__( 'Footer Sidebar', 'DOMAIN'),
        'id'            => 'sidebar-2',
        'description'   => __( 'Appears on footer', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          =>__( 'Search Sidebar', 'DOMAIN'),
        'id'            => 'sidebar-3',
        'description'   => __( 'Appears on footer', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    
    register_sidebar( array(
        'name'          => __( 'Slider Banner', 'DOMAIN'),
        'id'            => 'banner-sidebar',
        'description'   => __( 'Appears on footer', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          =>__( 'Newsletter Sidebar', 'DOMAIN'),
        'id'            => 'sidebar-4',
        'description'   => __( 'Appears on footer', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    
    register_sidebar( array(
        'name'          =>__( 'Copyright Sidebar', 'DOMAIN'),
        'id'            => 'sidebar-5',
        'description'   => __( 'Appears on miscellaneous locations', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    
    }
    add_action( 'widgets_init', 'induko_widgets_init' );
    // End Widgets

    // Custom Post Type 'Courses'
    function induko_courses_cpt(){
        $labels = array(
            'name'              =>  __( 'Courses', 'General name for the post type, usually plural', 'DOMAIN' ),
            'singular_name'     =>  __( 'Course', 'Name for one object of this post type', 'DOMAIN' ),
            'add_new'           =>  __( 'Add new', 'Default is ‘Add New’ for both hierarchical and non-hierarchical types', 'DOMAIN' ),
            'add_new_item'      =>  __( 'Add new course', 'Label for adding a new singular item', 'DOMAIN' ),
            'edit_item'         =>  __('Edit course', 'Label for editing a singular item', 'DOMAIN'),
            'view_item'         =>  __('View course', 'Label for viewing a singular item', 'DOMAIN'),
            'view_items'        =>  __('View courses', 'Label for viewing post type archives', 'DOMAIN'),
            'search_items'      =>  __('Search courses', 'Label for searching plural items', 'DOMAIN'),
            'not_found'         =>  __('Course Not Found', 'Label used when no items are found', 'DOMAIN'),
            'not_found_in_trash'=>  __('Course not found in trash', '', 'DOMAIN'),
            'all_items'         =>  __('All Courses', 'Label to signify all items in a submenu link', 'DOMAIN'),
            'archives'          =>  __('Course Archives', 'Label for archives in nav menus', 'DOMAIN'),
            'attributes'        =>  __('Course Attributes', 'Label for the attributes meta box', 'DOMAIN'),
        );
        $args = array(
            'labels'                =>  $labels,
            'description'           =>  'This Post for add new course',
            'public'                =>  true,
            'hierarchical'          =>  true,
            'publicly_queryable'    =>  true,
            'has_archive'           =>  true,
            'show_ui'               =>  true,
            'show_in_menu'          =>  true,
            'show_in_nav_menus'     =>  true,
            'show_in_admin_bar'     =>  true,
            'menu_position'         =>  3,
            'menu_icon'             =>  'dashicons-welcome-learn-more',
            'supports'              =>  array( 'title', 'editor', 'post-formats', 'thumbnail', 'comments' ),
            'rewrite'               =>  array( 'slug' => 'courses' ),
        
        );
        register_post_type( 'courses', $args );
    }
    add_action( 'init', 'induko_courses_cpt' );

// Register Taxonomy
function induko_skill_taxonomy(){
    $labels = array(
       'name'               => _x( 'Skills', 'Pogramming Skills Sets', 'DOMAIN'),
       'sigular_name'       => _x( 'Skill', 'Programming Singular Skills', 'DOMAIN'),
       'search_items'       => __( 'Search Skill Type'),
       'all_items'          => __( 'All Skill Types'),
       'parent_item'        => __( 'Parent Skill Type'),
       'parent_item_colon'  => __( 'Parent Skill Type'),
       'edit_item'          => __( 'Edit Skill Type'),
       'update_item'        => __( 'Update Skill Type'),
       'add_new_item'       => __( 'Add Skill Type'),
       'new_item_name'      => __( 'New Skill Type'),
       'menu_name'          => __( 'Skill Type'), 
    );
 
    $rewrite = array(
        'slug'              => array('skills'),
        'with_front'        => true,
        'hierarchical'      => true 
    );

    //Arguments
    $args = array(
       'hierarchical'       => true,
       'labels'             => $labels,
       'show_ui'            => true,
       'show_in_menu'       => true,
       'show_in_nav_menus'  => true,
       'show_admin_ui'      => true,
       'show_admin_colomn'  => true,
       'publicly_queryable' => true,
       'rewrite'            => $rewrite,
       'public'             => true,
	   'show_in_rest'       => true,
 
    );
	register_taxonomy( 'skills', array('courses'), $args);
	
 }
 add_action('init', 'induko_skill_taxonomy');


 /*****************
 *  AJAX Search
 ****************/

add_action( 'wp_footer', 'ajax_fetch' );
function ajax_fetch() {
?>
<script type="text/javascript">
function fetch(){

    jQuery.ajax({
        url: '<?php echo admin_url('admin-ajax.php'); ?>',
        type: 'post',
        data: { action: 'data_fetch', keyword: jQuery('#keyword').val() },
        success: function(data) {
            jQuery('#datafetch').html( data );
        }
    });

}
</script>

<?php
}
// Calling the ajax function
add_action('wp_ajax_data_fetch' , 'data_fetch');
add_action('wp_ajax_nopriv_data_fetch','data_fetch');
/**
 * First hook allows you to handle your custom AJAX endpoints. The wp_ajax_ hooks 
 * follows the format “wp_ajax_$action“, where $action is the ‘action‘ field submitted to admin-ajax.php
 * 
 * Second hook only fires for logged-in users. If your action only allows Ajax requests to come from users not
 * logged-in, you need to instead use wp_ajax_nopriv_$action 
 */

function data_fetch(){

    $the_query = new WP_Query( array( 'posts_per_page' => -1, 's' => esc_attr( $_POST['keyword'] ), 'post_type' => array('any') ) );
    if( $the_query->have_posts() ) :
        while( $the_query->have_posts() ): $the_query->the_post(); ?>

            <h2><a href="<?php echo esc_url( post_permalink() ); ?>"><?php the_title();?></a></h2>

        <?php endwhile;
        wp_reset_postdata();  
    endif;

    die();
}
/** End AJAX SEARCH **/





/*------------------------------------------------------*/
/*                HOOKS PRACTICE CODE                   */
/*------------------------------------------------------*/


/* Replaces the excerpt (...) with "Read More" text by a link */
function new_excerpt_more($more) {
	global $post;
 return '<div id="read-more"><a href="'. get_permalink($post->ID) . '"> Read more </a></div>';
}
add_filter('excerpt_more', 'new_excerpt_more');


add_filter( 'the_content', 'add_post_wrapper_content' );
function add_post_wrapper_content( $content ){
     return '<div class="post_custom_induko">'.$content.'</div>';
}

if( ! function_exists( 'custom_excerpt_length' ) )
{
    function custom_excerpt_length( $length )
    {
        return 30;
    }
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

add_filter( "the_excerpt", "add_class_to_excerpt" );
function add_class_to_excerpt( $excerpt ) {
    return str_replace('<p', '<p class="induko-excerpt"', $excerpt);
}

?>



<!-- <div class="row"> -->
<?php

// pre_get_posts: is a filter, for altering any query. It is most often used to alter only the 'main query'
/*
add_action('pre_get_posts', 'some_function_in_functionsphp');
$my_secondary_loop = new WP_Query(array( 'post_type' => 'courses' ) );
remove_action('pre_get_posts', 'some_function_in_functionsphp');

if( $my_secondary_loop->have_posts() ):
    while( $my_secondary_loop->have_posts() ): $my_secondary_loop->the_post();
?>

    <div class="col-md-12 col-sm-12">
        <h1 id="post-title"><a href="<?php echo get_post_permalink($post->ID) ?>"><?php the_title();?></a></h1>
    </div>
    <div class="col-md-12 col-sm-12">
        <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>
        <img id="feature-image" src="<?php echo $url; ?>" alt="" />
    </div>
    <div id="post-content" class="col-md-12 col-sm-12">
        <?php the_excerpt(); ?>
    </div>
    <div id="read-more" class="col-md-12 col-sm-12">
        <a href="<?php echo get_post_permalink($post->ID) ?>">Read More</a>
    </div>
<?php endwhile; ?>
<?php endif; ?>
<?php wp_reset_postdata(); ?>
</div>
*/



/**
* Redirect away from the single view for my_custom_post_type only
* if the user is not logged in
*/
/*
add_action('template_redirect', 'single_view_disable');
function single_view_disable() {
    global $post;
    if($post->post_type == 'courses' && is_single() && !is_user_logged_in()):
        // Redirect back home
        wp_redirect(home_url() );
        exit;
    endif;
}
*/


// Open website in new tab, button will show in admin header bar
function induko_custom_admin_menu_bar($wp_admin_bar){
    $args = array(
        "id"        =>   "induko-blog",
        "title"     =>  "<i class='fa fa-home' aria-hidden='true'></i>View Site",
        "href"      =>  "http://localhost/pl-task/",
        "meta"      =>  array(
            "class"     =>  "induko-custom-blog",
            "target"    =>  "_blank",
        )
    );
    $wp_admin_bar->add_node($args);
}
add_action( "admin_bar_menu", "induko_custom_admin_menu_bar", 999 );




/****************************************
 * Start code example-functions.php of cmb2
 ****************************************/
/**
 * Basic use of CMB2
 * https://github.com/CMB2/CMB2/wiki/Basic-Usage
 * https://github.com/CMB2/CMB2/wiki/Field-Types#types
 * 
 */

/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'induko_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/CMB2/CMB2
 */

/**
 * Get the bootstrap! If using the plugin from wordpress.org, REMOVE THIS!
 */

if ( file_exists( dirname( __FILE__ ) . '/cmb2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @param  CMB2 $cmb CMB2 object.
 *
 * @return bool      True if metabox should show
 */
function induko_show_if_front_page( $cmb ) {
	// Don't show this metabox if it's not the front page template.
	if ( get_option( 'page_on_front' ) !== $cmb->object_id ) {
		return false;
	}
	return true;
}

/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  CMB2_Field $field Field object.
 *
 * @return bool              True if metabox should show
 */
function induko_hide_if_no_cats( $field ) {
	// Don't show this field if not in the cats category.
	if ( ! has_tag( 'cats', $field->object_id ) ) {
		return false;
	}
	return true;
}

/**
 * Manually render a field.
 *
 * @param  array      $field_args Array of field arguments.
 * @param  CMB2_Field $field      The field object.
 */
function induko_render_row_cb( $field_args, $field ) {
	$classes     = $field->row_classes();
	$id          = $field->args( 'id' );
	$label       = $field->args( 'name' );
	$name        = $field->args( '_name' );
	$value       = $field->escaped_value();
	$description = $field->args( 'description' );
	?>
	<div class="custom-field-row <?php echo esc_attr( $classes ); ?>">
		<p><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></p>
		<p><input id="<?php echo esc_attr( $id ); ?>" type="text" name="<?php echo esc_attr( $name ); ?>" value="<?php echo $value; ?>"/></p>
		<p class="description"><?php echo esc_html( $description ); ?></p>
	</div>
	<?php
}

/**
 * Manually render a field column display.
 *
 * @param  array      $field_args Array of field arguments.
 * @param  CMB2_Field $field      The field object.
 */
function induko_display_text_small_column( $field_args, $field ) {
	?>
	<div class="custom-column-display <?php echo esc_attr( $field->row_classes() ); ?>">
		<p><?php echo $field->escaped_value(); ?></p>
		<p class="description"><?php echo esc_html( $field->args( 'description' ) ); ?></p>
	</div>
	<?php
}

/**
 * Conditionally displays a message if the $post_id is 2
 *
 * @param  array      $field_args Array of field parameters.
 * @param  CMB2_Field $field      Field object.
 */
function induko_before_row_if_2( $field_args, $field ) {
	if ( 2 == $field->object_id ) {
		echo '<p>Testing <b>"before_row"</b> parameter (on $post_id 2)</p>';
	} else {
		echo '<p>Testing <b>"before_row"</b> parameter (<b>NOT</b> on $post_id 2)</p>';
	}
}

add_action( 'cmb2_admin_init', 'induko_register_demo_metabox' );
/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_admin_init' or 'cmb2_init' hook.
 */
function induko_register_demo_metabox() {
	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$cmb_demo = new_cmb2_box( array(
		'id'            => 'induko_demo_metabox',
		'title'         => esc_html__( 'Test Metabox', 'cmb2' ),
		'object_types'  => array( 'courses' ), // Post type
		// 'show_on_cb' => 'induko_show_if_front_page', // function should return a bool value
		'context'       => 'normal', // Post edit screen contexts include 'normal', 'side', and 'advanced'. Default value: 'advanced'
		'priority'      => 'default', // The priority within the context where the box should show. Accepts 'high', 'core', 'default', or 'low'. Default value: 'default'
		// 'show_names' => true, // Show field names on the left. Default value: true
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // true to keep the metabox closed by default

		// 'classes_cb' => 'induko_add_some_classes', // Add classes through a callback.

		/*
		 * The following parameter is any additional arguments passed as $callback_args
		 * to add_meta_box, if/when applicable.
		 *
		 * CMB2 does not use these arguments in the add_meta_box callback, however, these args
		 * are parsed for certain special properties, like determining Gutenberg/block-editor
		 * compatibility.
		 *
		 * Examples:
		 *
		 * - Make sure default editor is used as metabox is not compatible with block editor
		 *      [ '__block_editor_compatible_meta_box' => false/true ]
		 *
		 * - Or declare this box exists for backwards compatibility
		 *      [ '__back_compat_meta_box' => false ]
		 *
		 * More: https://wordpress.org/gutenberg/handbook/extensibility/meta-box/
		 */
		// 'mb_callback_args' => array( '__block_editor_compatible_meta_box' => false ),
	) );

	$cmb_demo->add_field( array(
		'name'       => esc_html__( 'Induko Text', 'cmb2' ),
		'desc'       => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'         => 'induko_demo_text',
		'type'       => 'text',
		'show_on_cb' => 'induko_hide_if_no_cats', // function should return a bool value
		// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
		// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
		// 'on_front'        => false, // Optionally designate a field to wp-admin only
		// 'repeatable'      => true,
		// 'column'          => true, // Display field value in the admin post-listing columns
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Courses Text Small', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_textsmall',  // id use to display in frontend
		'type' => 'text_small',
		// 'repeatable' => true,
		// 'column' => array(
		// 	'name'     => esc_html__( 'Column Title', 'cmb2' ), // Set the admin column title
		// 	'position' => 2, // Set as the second column.
		// );
		// 'display_cb' => 'induko_display_text_small_column', // Output the display of the column values through a callback.
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Coureses Brief Summary', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_textmedium',
		'type' => 'text_medium',
	) );

	$cmb_demo->add_field( array(
		'name'       => esc_html__( 'Read-only Disabled Field', 'cmb2' ),
		'desc'       => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'         => 'induko_demo_readonly',
		'type'       => 'text_medium',
		'default'    => esc_attr__( 'Hey there, I\'m a read-only field', 'cmb2' ),
		'save_field' => false, // Disables the saving of this field.
		'attributes' => array(
			'disabled' => 'disabled',
			'readonly' => 'readonly',
		),
	) );


	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Website URL', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_url',
		'type' => 'text_url',
		'protocols' => array('http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet'), // Array of allowed protocols
		// 'repeatable' => true,
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Enter Email', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_email',
		'type' => 'text_email',
		// 'repeatable' => true,
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Add Time', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_time',
		'type' => 'text_time',
		// 'time_format' => 'H:i', // Set to 24hr format
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Time zone', 'cmb2' ),
		'desc' => esc_html__( 'Time zone', 'cmb2' ),
		'id'   => 'induko_demo_timezone',
		'type' => 'select_timezone',
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Choose Event Date from Picker', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_textdate',
		'type' => 'text_date',
		// 'date_format' => 'Y-m-d',
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Test Date Picker (UNIX timestamp)', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_textdate_timestamp',
		'type' => 'text_date_timestamp',
		// 'timezone_meta_key' => 'induko_demo_timezone', // Optionally make this field honor the timezone selected in the select_timezone specified above
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Test Date/Time Picker Combo (UNIX timestamp)', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_datetime_timestamp',
		'type' => 'text_datetime_timestamp',
	) );

	// This text_datetime_timestamp_timezone field type
	// is only compatible with PHP versions 5.3 or above.
	// Feel free to uncomment and use if your server meets the requirement
	// $cmb_demo->add_field( array(
	// 	'name' => esc_html__( 'Test Date/Time Picker/Time zone Combo (serialized DateTime object)', 'cmb2' ),
	// 	'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
	// 	'id'   => 'induko_demo_datetime_timestamp_timezone',
	// 	'type' => 'text_datetime_timestamp_timezone',
	// ) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Test Money', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_textmoney',
		'type' => 'text_money',
		'before_field' => 'Rs.', // Uncomment to override '$' symbol if needed
		// 'repeatable' => true,
	) );

	$cmb_demo->add_field( array(
		'name'    => esc_html__( 'Test Color Picker', 'cmb2' ),
		'desc'    => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'      => 'induko_demo_colorpicker',
		'type'    => 'colorpicker',
		'default' => '#ffffff',
		// 'options' => array(
		// 	'alpha' => true, // Make this a rgba color picker.
		// ),
		// 'attributes' => array(
		// 	'data-colorpicker' => json_encode( array(
		// 		'palettes' => array( '#3dd0cc', '#ff834c', '#4fa2c0', '#0bc991', ),
		// 	) ),
		// ),
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Test Text Area', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_textarea',
		'type' => 'textarea',
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Test Text Area Small', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_textareasmall',
		'type' => 'textarea_small',
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Test Text Area for Code', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_textarea_code',
		'type' => 'textarea_code',
	) );

	$cmb_demo->add_field( array(
		'name'             => esc_html__( 'Test Select', 'cmb2' ),
		'desc'             => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'               => 'induko_demo_select',
		'type'             => 'select',
		'show_option_none' => true,
		'options'          => array(
			'standard' => esc_html__( 'Option One', 'cmb2' ),
			'custom'   => esc_html__( 'Option Two', 'cmb2' ),
			'none'     => esc_html__( 'Option Three', 'cmb2' ),
		),
	) );

	$cmb_demo->add_field( array(
		'name'             => esc_html__( 'Select Gender', 'cmb2' ),
		'desc'             => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'               => 'induko_demo_radio_inline',
		'type'             => 'radio_inline',
		'show_option_none' => 'No Selection',
		'options'          => array(
			'Male' => esc_html__( 'Male', 'cmb2' ),
			'Female'   => esc_html__( 'Female', 'cmb2' ),
			'Shemale'     => esc_html__( 'Shemale', 'cmb2' ),
		),
	) );
    // same as above radio selection
	$cmb_demo->add_field( array(
		'name'    => esc_html__( 'Test Radio', 'cmb2' ),
		'desc'    => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'      => 'induko_demo_radio',
		'type'    => 'radio',
		'options' => array(
			'option1' => esc_html__( 'Option One', 'cmb2' ),
			'option2' => esc_html__( 'Option Two', 'cmb2' ),
			'option3' => esc_html__( 'Option Three', 'cmb2' ),
		),
	) );

	$cmb_demo->add_field( array(
		'name'     => esc_html__( 'Test Taxonomy Radio', 'cmb2' ),
		'desc'     => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'       => 'induko_demo_text_taxonomy_radio',
		'type'     => 'taxonomy_radio', // Or `taxonomy_radio_inline`/`taxonomy_radio_hierarchical`
		'taxonomy' => 'skills', // Taxonomy Slug
		// 'inline'  => true, // Toggles display to inline
		// Optionally override the args sent to the WordPress get_terms function.
		'query_args' => array(
			'orderby' => 'slug',
			'hide_empty' => true,
		),
	) );

	$cmb_demo->add_field( array(
		'name'     => esc_html__( 'Test Taxonomy Select', 'cmb2' ),
		'desc'     => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'       => 'induko_demo_taxonomy_select',
		'type'     => 'taxonomy_select', // Or `taxonomy_select_hierarchical`
		'taxonomy' => 'skills', // Taxonomy Slug
	) );

	$cmb_demo->add_field( array(
		'name'     => esc_html__( 'Test Taxonomy Multi Checkbox', 'cmb2' ),
		'desc'     => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'       => 'induko_demo_multitaxonomy',
		'type'     => 'taxonomy_multicheck', // Or `taxonomy_multicheck_inline`/`taxonomy_multicheck_hierarchical`
		'taxonomy' => 'post_tag', // Taxonomy Slug
		// 'inline'  => true, // Toggles display to inline
	) );

	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Test Checkbox', 'cmb2' ),
		'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'   => 'induko_demo_checkbox',
		'type' => 'checkbox',
	) );

	$cmb_demo->add_field( array(
		'name'    => esc_html__( 'Select One/More Course/es', 'cmb2' ),
		'desc'    => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'      => 'induko_demo_multicheckbox',
		'type'    => 'multicheck',
		// 'multiple' => true, // Store values in individual rows
		'options' => array(
			'BSCS' => esc_html__( 'BSCS', 'cmb2' ),
			'BSIT' => esc_html__( 'BSIT', 'cmb2' ),
			'B.A' => esc_html__( 'B.A', 'cmb2' ),
			'LLB' => esc_html__( 'LLB', 'cmb2' ),
		),
		// 'inline'  => true, // Toggles display to inline
	) );

	$cmb_demo->add_field( array(
		'name'    => esc_html__( 'Test wysiwyg', 'cmb2' ),
		'desc'    => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'      => 'induko_demo_wysiwyg',
		'type'    => 'wysiwyg',
		'options' => array(
			'textarea_rows' => 5,
		),
	) );
	// This feature is broken when upload image
	/*
	$cmb_demo->add_field( array(
		'name' => esc_html__( 'Test Image', 'cmb2' ),
		'desc' => esc_html__( 'Upload an image or enter a URL.', 'cmb2' ),
		'id'   => 'induko_demo_image',
		'type' => 'file',
		'options' => array(
			'url' => false, // false if Hide the text input for the url
		),
		'text'    => array(
			'add_upload_file_text' => 'Add File' // Change upload button text. Default: "Add or Upload File"
		),
		'query_args' => array(
			 'type' => array(
				 'image/gif',
				 'image/jpeg',
				 'image/jpg',
				 'image/png',
			 ),
		// 'preview_size' => 'large', // Image size to use when previewing in the admin.
		)
	) );
	

	$cmb_demo->add_field( array(
		'name'         => esc_html__( 'Multiple Files', 'cmb2' ),
		'desc'         => esc_html__( 'Upload or add multiple images/attachments.', 'cmb2' ),
		'id'           => 'induko_demo_file_list',
		'type'         => 'file_list',
		'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
	) );
	*/

}

/************** End metabox for Custom Post Type ***************/

add_action( 'cmb2_admin_init', 'induko_register_theme_options_metabox' );
/**
 * Hook in and register a metabox to handle a theme options page and adds a menu item.
 */
function induko_register_theme_options_metabox() {

	/**
	 * Registers options page menu item and form.
	 */
	$cmb_options = new_cmb2_box( array(
		'id'           => 'induko_theme_options_page',
		'title'        => esc_html__( 'Theme Options', 'cmb2' ),
		'object_types' => array( 'options-page' ),

		/*
		 * The following parameters are specific to the options-page box
		 * Several of these parameters are passed along to add_menu_page()/add_submenu_page().
		 */

		'option_key'      => 'induko_theme_options', // The option key and admin menu page slug.
		'icon_url'        => 'dashicons-palmtree', // Menu icon. Only applicable if 'parent_slug' is left empty.
		// 'menu_title'      => esc_html__( 'Options', 'cmb2' ), // Falls back to 'title' (above).
		// 'parent_slug'     => 'themes.php', // Make options page a submenu item of the themes menu.
		// 'capability'      => 'manage_options', // Cap required to view options-page.
		// 'position'        => 1, // Menu position. Only applicable if 'parent_slug' is left empty.
		// 'admin_menu_hook' => 'network_admin_menu', // 'network_admin_menu' to add network-level options page.
		// 'display_cb'      => false, // Override the options-page form output (CMB2_Hookup::options_page_output()).
		// 'save_button'     => esc_html__( 'Save Theme Options', 'cmb2' ), // The text for the options-page save button. Defaults to 'Save'.
		// 'disable_settings_errors' => true, // On settings pages (not options-general.php sub-pages), allows disabling.
		// 'message_cb'      => 'induko_options_page_message_callback',
		// 'tab_group'       => '', // Tab-group identifier, enables options page tab navigation.
		// 'tab_title'       => null, // Falls back to 'title' (above).
		// 'autoload'        => false, // Defaults to true, the options-page option will be autloaded.
	) );

	/**
	 * Options fields ids only need
	 * to be unique within this box.
	 * Prefix is not needed.
	 */
	$cmb_options->add_field( array(
		'name'    => esc_html__( 'Site Background Color', 'cmb2' ),
		'desc'    => esc_html__( 'field description (optional)', 'cmb2' ),
		'id'      => 'bg_color',
		'type'    => 'colorpicker',
		'default' => '#ffffff',
	) );

}

/**
 * Callback to define the optionss-saved message.
 *
 * @param CMB2  $cmb The CMB2 object.
 * @param array $args {
 *     An array of message arguments
 *
 *     @type bool   $is_options_page Whether current page is this options page.
 *     @type bool   $should_notify   Whether options were saved and we should be notified.
 *     @type bool   $is_updated      Whether options were updated with save (or stayed the same).
 *     @type string $setting         For add_settings_error(), Slug title of the setting to which
 *                                   this error applies.
 *     @type string $code            For add_settings_error(), Slug-name to identify the error.
 *                                   Used as part of 'id' attribute in HTML output.
 *     @type string $message         For add_settings_error(), The formatted message text to display
 *                                   to the user (will be shown inside styled `<div>` and `<p>` tags).
 *                                   Will be 'Settings updated.' if $is_updated is true, else 'Nothing to update.'
 *     @type string $type            For add_settings_error(), Message type, controls HTML class.
 *                                   Accepts 'error', 'updated', '', 'notice-warning', etc.
 *                                   Will be 'updated' if $is_updated is true, else 'notice-warning'.
 * }
 */
function induko_options_page_message_callback( $cmb, $args ) {
	if ( ! empty( $args['should_notify'] ) ) {

		if ( $args['is_updated'] ) {

			// Modify the updated message.
			$args['message'] = sprintf( esc_html__( '%s &mdash; Updated!', 'cmb2' ), $cmb->prop( 'title' ) );
		}

		add_settings_error( $args['setting'], $args['code'], $args['message'], $args['type'] );
	}
}

/**
 * Only show this box in the CMB2 REST API if the user is logged in.
 *
 * @param  bool                 $is_allowed     Whether this box and its fields are allowed to be viewed.
 * @param  CMB2_REST_Controller $cmb_controller The controller object.
 *                                              CMB2 object available via `$cmb_controller->rest_box->cmb`.
 *
 * @return bool                 Whether this box and its fields are allowed to be viewed.
 */
function induko_limit_rest_view_to_logged_in_users( $is_allowed, $cmb_controller ) {
	if ( ! is_user_logged_in() ) {
		$is_allowed = false;
	}

	return $is_allowed;
}

add_action( 'cmb2_init', 'induko_register_rest_api_box' );
/**
 * Hook in and add a box to be available in the CMB2 REST API. Can only happen on the 'cmb2_init' hook.
 * More info: https://github.com/CMB2/CMB2/wiki/REST-API
 */
function induko_register_rest_api_box() {
	$cmb_rest = new_cmb2_box( array(
		'id'            => 'induko_rest_metabox',
		'title'         => esc_html__( 'REST Test Box', 'cmb2' ),
		'object_types'  => array( 'page' ), // Post type
		'show_in_rest' => WP_REST_Server::ALLMETHODS, // WP_REST_Server::READABLE|WP_REST_Server::EDITABLE, // Determines which HTTP methods the box is visible in.
		// Optional callback to limit box visibility.
		// See: https://github.com/CMB2/CMB2/wiki/REST-API#permissions
		// 'get_box_permissions_check_cb' => 'induko_limit_rest_view_to_logged_in_users',
	) );

	$cmb_rest->add_field( array(
		'name'       => esc_html__( 'REST Test Text', 'cmb2' ),
		'desc'       => esc_html__( 'Will show in the REST API for this box and for pages.', 'cmb2' ),
		'id'         => 'induko_rest_text',
		'type'       => 'text',
	) );

	$cmb_rest->add_field( array(
		'name'       => esc_html__( 'REST Editable Test Text', 'cmb2' ),
		'desc'       => esc_html__( 'Will show in REST API "editable" contexts only (`POST` requests).', 'cmb2' ),
		'id'         => 'induko_rest_editable_text',
		'type'       => 'text',
		'show_in_rest' => WP_REST_Server::EDITABLE,// WP_REST_Server::ALLMETHODS|WP_REST_Server::READABLE, // Determines which HTTP methods the field is visible in. Will override the cmb2_box 'show_in_rest' param.
	) );
}

/**Use CMB2 to Create a New Post Submission Form**/






