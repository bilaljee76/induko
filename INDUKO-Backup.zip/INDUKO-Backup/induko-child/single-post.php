<?php
/**
 * Template Name: Post Single
*/
get_header();
?>
<!-- section -->
<section class="main_full inner_page">
    <div class="container-fluid">
        <div class="row">
            <div class="full">
            <!-- <h3 class="custom-page-title">Coaching</h3>     -->
            </div>
        </div>
    </div>
</section>
<!-- end section -->

</section>


<div class="container" id="blog-container">
    <div class="row">
        
        <?php if(have_posts() ): while(have_posts() ) : the_post(); ?>
        <div id="post-<?php echo get_the_ID(); ?>">
            <div class="col-md-12 col-sm-12">
                <h1 id="post-title"><a href="<?php echo get_post_permalink($post->ID); ?>"><?php the_title();?></a></h1>
            </div>
            <!-- <div class="col-md-12 col-sm-12">
                <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID), 'thumbnail' ); ?>
                <img id="feature-image" src="<?php echo $url; ?>" alt="" />
            </div> -->
            <div id="post-content" class="col-md-12 col-sm-12">
                <?php the_content(); ?>
            </div>
        </div>
        <?php endwhile; ?>
        <?php endif; ?>
    </div><!-- /row -->
</div><!-- /Container -->


<?php get_footer(); ?>