<?php 
/**
 * Template Name: Time
 */
?>
<?php get_header(); ?>
      <!-- section -->
      <section class="main_full inner_page">
        <div class="container-fluid">
          <div class="row">
             <div class="full">
               <h3>Time</h3>    
             </div>
          </div>
        </div>
      </section>
      <!-- end section -->

      <!-- section -->
      <?php
   /* Get content from wordpress page and show it on another page / in custom template */ 
     
     $args = array( 'post_type' => 'page','page_id' => 14 );
     $the_query = new WP_Query( $args );
     while ( $the_query->have_posts() ) :
     $the_query->the_post();
     the_content();
     endwhile;
     wp_reset_postdata();
     
?>
      <!-- end section -->

<?php get_footer(); ?>