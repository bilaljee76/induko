<!DOCTYPE <?php bloginfo( 'html_type' ); ?>>
<html lang="<?php bloginfo( 'language' ); ?>">
<!-- Basic -->
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Mobile Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Site Metas -->
<title><?php bloginfo( 'name' ); ?></title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">
<!-- site icon -->
<!-- <link rel="icon" href="<?php bloginfo( "template_url" ); ?>/images/fevicon.png" type="image/png" /> -->
<!-- Bootstrap core CSS -->
<!-- <link href="css/bootstrap.css" rel="stylesheet"> -->
<!-- FontAwesome Icons core CSS -->
<!-- <link href="css/font-awesome.min.css" rel="stylesheet"> -->
<!-- Custom animate styles for this template -->
<!-- <link href="css/animate.css" rel="stylesheet"> -->
<!-- Custom styles for this template -->
<!-- <link href="style.css" rel="stylesheet"> -->
<!-- Responsive styles for this template -->
<!-- <link href="css/responsive.css" rel="stylesheet"> -->
<!-- Colors for this template -->
<!-- <link href="css/colors.css" rel="stylesheet"> -->
<!-- light box gallery -->
<!-- <link href="css/ekko-lightbox.css" rel="stylesheet"> -->
<!--[if lt IE 9]>
   <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
   <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
   <![endif]-->
</head>

<body id="home_page" <?php body_class(array('home-page', 'induko-custom-body-class')); ?>>
    <!-- header -->
    <header class="header">

        <div class="header_top_section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="full">
                            <div class="logo">
                                <?php
                                // $custom_logo_id = get_theme_mod( 'custom_logo' );
                                // $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );

                                ?>
                                <img src="<?php // echo $image[0]; ?>" alt="">
                                
                                <a href="index.html"><img src="http://localhost/pl-task/wp-content/uploads/2020/11/logo.png" alt="<?php the_title(); ?>" /></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9 site_information">
                        <div class="full">
                            <div class="main_menu">
                                <nav class="navbar navbar-inverse navbar-toggleable-md">
                                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                                        data-target="#cloapediamenu" aria-controls="cloapediamenu" aria-expanded="false"
                                        aria-label="Toggle navigation">
                                        <span class="float-left">Menu</span>
                                        <span class="float-right"><i class="fa fa-bars"></i> <i
                                                class="fa fa-close"></i></span>
                                    </button>
                                    <div class="collapse navbar-collapse justify-content-md-center" id="cloapediamenu">
                                        <?php

                                        wp_nav_menu( $args = array(
                                            'theme_location'    =>  'top_menu',
                                            'menu_class'        =>  'navbar-nav', // add ul classes here
                                            'menu_id'           =>  'main-menu',
                                            'container'         =>  '',
                                            'depth'             =>  0,
                                            'items_wrap'        =>  '<ul id="%1$s" class="%2$s">%3$s</ul>',
                                            'add_li_class'      =>  'nav-item',
                                            'add_anchor_class'  =>  'nav-link',
                                            'fallback_cb'       =>  false,

                                        ) );

                                        ?>
                              
                                        <!-- <ul class="navbar-nav">
                                 <li class="nav-item active">
                                    <a class="nav-link" href="index.html">Home</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-aqua-hover" href="about.html">About</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-aqua-hover" href="coaching.html">Coaching</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-grey-hover" href="time.html">Time</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-grey-hover" href="contact.html">Contact Us</a>
                                 </li>
                                 <li class="nav-item">
                                    <a class="nav-link color-grey-hover" href="contact.html">Login</a>
                                 </li>
                              </ul> -->


                                <!-- Add search icon png image using sidebar (widget) -->
                                <?php if ( is_active_sidebar( 'sidebar-3' ) ) : ?>
                                    <?php dynamic_sidebar( 'sidebar-3' ); ?>
                                <?php endif; ?>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
                
                <div class="search-bar">
                    <input type="text" class="search-input" name="keyword" id="keyword" onkeyup="fetch()">
                    <div id="datafetch" style="background-color:#fff;"></div>
                </div>

            </div>
        </div>
    </div>

</header>
<!-- end header -->
<?php wp_head(); ?>