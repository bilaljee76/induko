<?php
// Modify the default loop, include custom post types
global $wp_query;
$args = array_merge( $wp_query->query, array( 'post_type' => 'any' ) );
query_posts( $args );

if(have_posts() ) :
    while( have_posts() ) :
        the_post();
        the_title( "<h2>", "</h2>", true );
        the_content( "<p>", "</p>", true );
    endwhile;
endif;