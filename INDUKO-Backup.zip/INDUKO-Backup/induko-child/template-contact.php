<?php 
/**
 * Template Name: Contact
 */
?>
<?php get_header(); ?>
<!-- section -->
<section class="main_full inner_page">
   <div class="container-fluid">
      <div class="row">
         <div class="full">
         <h3>Contact</h3>    
         </div>
      </div>
   </div>
</section>
<!-- end section -->
    
    <!-- section -->

    <?php
   /* Get content from wordpress page and show it on another page / in custom template */ 
     
     $args = array( 'post_type' => 'page','page_id' => 16 );
     $the_query = new WP_Query( $args );
     while ( $the_query->have_posts() ) :
     $the_query->the_post();
     the_content();
     endwhile;
     wp_reset_postdata();  
   ?>
     <!-- <section class="layout_padding section">
         <div class="container">
           <div class="row">
               <div class="col-md-12">
                  <div class="contact_section margin_top_30">
                     <div class="row">
                        <div class="col-md-8 offset-md-2">
                           <div class="form_cont"> -->
                              <?php // echo do_shortcode('[contact-form-7 id="84" title="Contact us"]'); ?>
                               <!-- <form action="index.html">
                                  <fieldset>
                                     <div class="field">
                                        <input type="text" name="name" placeholder="Name">
                                     </div>
                                     <div class="field">
                                        <input type="email" name="email" placeholder="Email">
                                     </div>
                                     <div class="field">
                                        <input type="text" name="phone" placeholder="Phone">
                                     </div>
                                     <div class="field">
                                        <textarea placeholder="Message"></textarea>
                                     </div>
                                     <div class="field center">
                                       <button>Send</button>
                                  </div></fieldset>
                               </form> -->
                           <!-- </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section> -->
      <!-- end section -->
  
<?php get_footer(); ?>