<?php get_header(); ?>

<?php 
    if(have_posts() ) : the_post(); 
        rewind_posts(); 
    endif;
    if( 'courses' == get_post_type() ) :
        include(TEMPLATEPATH. '/single-courses.php');
    endif;
    if( 'induko_news' == get_post_type() ) :
        include(TEMPLATEPATH. '/single-news.php');
    endif;
    if( 'post' == get_post_type() ) :
        include(TEMPLATEPATH. '/single-post.php');
    endif;
?>

<?php get_footer(); ?>