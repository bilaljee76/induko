<?php


if ( ! defined( 'DOMAIN' ) ) {
	// Replace the version number of the theme on each release.
	define( 'DOMAIN', 'induko' );
}


if ( ! defined( 'VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( 'VERSION', '1.0.0' );
}


/**Include Styles and Scripts */
add_action( 'wp_enqueue_scripts', 'induko_scripts' );
function induko_scripts(){

    wp_enqueue_style( 'style', get_stylesheet_directory_uri(). '/style.css', 'VERSION', 'all' );
    wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri(). '/css/bootstrap.css', 'VERSION', 'all');
    wp_enqueue_style( 'font-awesome', get_stylesheet_directory_uri(). '/css/font-awesome.min.css', 1, 'all' );
    wp_enqueue_style( 'animate', get_stylesheet_directory_uri(). '/css/animate.css', 'VERSION', 'all' );
    wp_enqueue_style( 'responsive', get_stylesheet_directory_uri(). '/css/responsive.css', 'VERSION', 'all' );
    wp_enqueue_style( 'colors', get_stylesheet_directory_uri(). '/css/colors.css', 'VERSION', 'all' );
    wp_enqueue_style( 'ekko-lightbox', get_stylesheet_directory_uri(). '/css/ekko-lightbox.css', 'VERSION', 'all' );

    wp_enqueue_style( 'editor-style', get_stylesheet_directory_uri(). '/assets/css/editor-style.css', 'VERSION', 'all' );

    
    wp_enqueue_script( 'jquery', get_stylesheet_directory_uri(). '/js/jquery.min.js', array('jquery'), false, true );
    wp_enqueue_script( 'tether', get_stylesheet_directory_uri(). '/js/tether.min.js', array('jquery'), false, true );
    wp_enqueue_script( 'bootstrap', get_stylesheet_directory_uri(). '/js/bootstrap.min.js', array('jquery'), false, true );
    wp_enqueue_script( 'parallax', get_stylesheet_directory_uri(). '/js/parallax.js', array('jquery'), false, true );
    wp_enqueue_script( 'animate', get_stylesheet_directory_uri(). '/js/animate.js', array('jquery'), false, true );
    wp_enqueue_script( 'ekko-lightbox', get_stylesheet_directory_uri(). '/js/ekko-lightbox.js', array('jquery'), false, true );
    wp_enqueue_script( 'custom', get_stylesheet_directory_uri(). '/js/custom.js', array('jquery'), false, true );
}

// Theme Support Added Here

function induko_support_init() {
	// For Menu Support
	add_theme_support( 'menu' );

	// For Comments Link
	add_theme_support( 'automatic_feed_links' );

	// For HTML5 Support
	add_theme_support( 'html5', array( 'comment-link', 'comment-form', 'search-form', 'gallery', 'caption' ) );
    
    // For Custom Background
	$defualt_bg = array(
		'default-image'				=>	'',		// get_template_directory_uri() . '/images/background.jpg'
		'default-preset'     		=> 'default', // 'default', 'fill', 'fit', 'repeat', 'custom'
    	'default-position-x'     	=> 'left',    // 'left', 'center', 'right'
    	'default-position-y'     	=> 'top',     // 'top', 'center', 'bottom'
    	'default-size'           	=> 'auto',    // 'auto', 'contain', 'cover'
    	'default-repeat'         	=> 'no-repeat',  // 'repeat-x', 'repeat-y', 'repeat', 'no-repeat'
    	'default-attachment'    	=> 'fixed',  // 'scroll', 'fixed'
    	'default-color'          	=> '',
    	'admin-head-callback'    	=> '',
    	'admin-preview-callback' 	=> '',

	);
	add_theme_support( 'custom-background', $defualt_bg );

	// For custom Logo
	add_theme_support( 'custom_logo', array(
		'height' => 105,
		'width' => 277,
		'flex-height' => true,
		'flex-width' => true,
		'header-text' => array( 'site-title', 'site-description' ),
    ) );
    
	// For Post Thumbnail

	add_theme_support( 'post-thumbnails' );
	//the_post_thumbnail('post-thumbnail', ['class' => 'img-responsive responsive--full', 'title' => 'Feature image']);
	the_post_thumbnail( 'thumbnail');       // Thumbnail (default 150px x 150px max)
	the_post_thumbnail( 'medium' );          // Medium resolution (default 300px x 300px max)
	the_post_thumbnail( 'large' );           // Large resolution (default 640px x 640px max)
	the_post_thumbnail( 'full' );            // Full resolution (original size uploaded)
	add_image_size( 'custom-size', 220, 180 ); // 220 pixels wide by 180 pixels tall, soft proportional crop mode


	// Editor Styles
	add_theme_support( 'editor-styles' );

	// Turn on Wide images
	add_theme_support( 'align-wide' );

	// Block Color Palettes
	add_theme_support( 'editor-color-palette', array(
    array(
        'name' => __( 'strong magenta', 'DOMAIN' ),
        'slug' => 'strong-magenta',
        'color' => '#a156b4',
    ),
    array(
        'name' => __( 'light grayish magenta', 'DOMAIN' ),
        'slug' => 'light-grayish-magenta',
        'color' => '#d0a5db',
    ),
    array(
        'name' => __( 'very light gray', 'DOMAIN' ),
        'slug' => 'very-light-gray',
        'color' => '#eee',
    ),
    array(
        'name' => __( 'very dark gray', 'DOMAIN' ),
        'slug' => 'very-dark-gray',
        'color' => '#444',
    ),
	) );

	
	// Block Font Sizes
	add_theme_support( 'editor-font-sizes', array(
    array(
        'name' => __( 'Small', 'DOMAIN' ),
        'size' => 12,
        'slug' => 'small'
    ),
    array(
        'name' => __( 'Normal', 'DOMAIN' ),
        'size' => 16,
        'slug' => 'normal'
    ),
    array(
        'name' => __( 'Large', 'DOMAIN' ),
        'size' => 36,
        'slug' => 'large'
    ),
    array(
        'name' => __( 'Huge', 'DOMAIN' ),
        'size' => 50,
        'slug' => 'huge'
    )
    ) );



    // Custom header
	$defaults = array(
    	'default-image'          => '',
    	'random-default'         => false,
    	'width'                  => 0,
    	'height'                 => 0,
    	'flex-height'            => false,
    	'flex-width'             => false,
    	'default-text-color'     => '',
    	'header-text'            => true,
    	'uploads'                => true,
    	'wp-head-callback'       => '',
    	'admin-head-callback'    => '',
    	'admin-preview-callback' => '',
    	'video'                  => false,
    	'video-active-callback'  => 'is_front_page',
	);
	add_theme_support( 'custom-header', $defaults );


}
add_action( 'after_setup_theme','induko_support_init' );

/**End Theme Support Function/Hook */

// Induko Theme Menu Register Here

function register_induko_menu() {
	register_nav_menus( array(
		'top_menu'	    =>	__( 'Top Menu', 'DOMAIN' ),
        'sidebar_menu'  =>  __( 'Sidebar Menu', 'DOMAIN' ),
        'footer_one'	=>	__( 'Footer Left One', 'DOMAIN' ),
        'footer_two'	=>	__( 'Footer Left Two', 'DOMAIN' ),
        'footer_three'	=>	__( 'Footer Left Three', 'DOMAIN' ),
	) );	
}
add_action( 'after_setup_theme', 'register_induko_menu' );

// Make FILTER to add menu anchor class/classes in wordpress nav_menu
function add_additional_class_on_li($classes, $item, $args) {
    if(isset($args->add_li_class)) {
        $classes[] = $args->add_li_class;
    }
    return $classes;
}
add_filter('nav_menu_css_class', 'add_additional_class_on_li', 10, 3);

// Make FILTER to add menu anchor class/classes in wordpress nav_menu
function add_menu_achor_class( $atts, $item, $args ) {
    if(isset($args->add_anchor_class)) {
        $atts['class'] = $args->add_anchor_class;
    }
    return $atts;
    }
add_filter( 'nav_menu_link_attributes', 'add_menu_achor_class', 10, 3 );
/**End Theme Menu */


// Register Widgets

function induko_widgets_init() {
 
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'DOMAIN' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'The main sidebar appears on the right on each page except the front page template', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
 
    register_sidebar( array(
        'name'          =>__( 'Footer Sidebar', 'DOMAIN'),
        'id'            => 'sidebar-2',
        'description'   => __( 'Appears on footer', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          =>__( 'Search Sidebar', 'DOMAIN'),
        'id'            => 'sidebar-3',
        'description'   => __( 'Appears on footer', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    
    register_sidebar( array(
        'name'          => __( 'Slider Banner', 'DOMAIN'),
        'id'            => 'banner-sidebar',
        'description'   => __( 'Appears on footer', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          =>__( 'Newsletter Sidebar', 'DOMAIN'),
        'id'            => 'sidebar-4',
        'description'   => __( 'Appears on footer', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    
    register_sidebar( array(
        'name'          =>__( 'Copyright Sidebar', 'DOMAIN'),
        'id'            => 'sidebar-5',
        'description'   => __( 'Appears on miscellaneous locations', 'DOMAIN' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    
    }
    add_action( 'widgets_init', 'induko_widgets_init' );
    // End Widgets

    // Custom Post Type 'Courses'
    function induko_courses_cpt(){
        $labels = array(
            'name'              =>  __( 'Courses', 'General name for the post type, usually plural', 'DOMAIN' ),
            'singular_name'     =>  __( 'Course', 'Name for one object of this post type', 'DOMAIN' ),
            'add_new'           =>  __( 'Add new', 'Default is ‘Add New’ for both hierarchical and non-hierarchical types', 'DOMAIN' ),
            'add_new_item'      =>  __( 'Add new course', 'Label for adding a new singular item', 'DOMAIN' ),
            'edit_item'         =>  __('Edit course', 'Label for editing a singular item', 'DOMAIN'),
            'view_item'         =>  __('View course', 'Label for viewing a singular item', 'DOMAIN'),
            'view_items'        =>  __('View courses', 'Label for viewing post type archives', 'DOMAIN'),
            'search_items'      =>  __('Search courses', 'Label for searching plural items', 'DOMAIN'),
            'not_found'         =>  __('Course Not Found', 'Label used when no items are found', 'DOMAIN'),
            'not_found_in_trash'=>  __('Course not found in trash', '', 'DOMAIN'),
            'all_items'         =>  __('All Courses', 'Label to signify all items in a submenu link', 'DOMAIN'),
            'archives'          =>  __('Course Archives', 'Label for archives in nav menus', 'DOMAIN'),
            'attributes'        =>  __('Course Attributes', 'Label for the attributes meta box', 'DOMAIN'),
        );
        $args = array(
            'labels'                =>  $labels,
            'description'           =>  'This Post for add new course',
            'public'                =>  true,
            'hierarchical'          =>  true,
            'publicly_queryable'    =>  true,
            'has_archive'           =>  true,
            'show_ui'               =>  true,
            'show_in_menu'          =>  true,
            'show_in_nav_menus'     =>  true,
            'show_in_admin_bar'     =>  true,
            'menu_position'         =>  3,
            'menu_icon'             =>  'dashicons-welcome-learn-more',
            'supports'              =>  array( 'title', 'editor', 'thumbnail', 'comments' ),
            'rewrite'               =>  array( 'slug' => 'courses' ),
        
        );
        register_post_type( 'courses', $args );
    }
    add_action( 'init', 'induko_courses_cpt' );

/*****************
 *  AJAX Search
 ****************/

add_action( 'wp_footer', 'ajax_fetch' );
function ajax_fetch() {
?>
<script type="text/javascript">
function fetch(){

    jQuery.ajax({
        url: '<?php echo admin_url('admin-ajax.php'); ?>',
        type: 'post',
        data: { action: 'data_fetch', keyword: jQuery('#keyword').val() },
        success: function(data) {
            jQuery('#datafetch').html( data );
        }
    });

}
</script>

<?php
}
// Calling the ajax function
add_action('wp_ajax_data_fetch' , 'data_fetch');
add_action('wp_ajax_nopriv_data_fetch','data_fetch');
/**
 * First hook allows you to handle your custom AJAX endpoints. The wp_ajax_ hooks 
 * follows the format “wp_ajax_$action“, where $action is the ‘action‘ field submitted to admin-ajax.php
 * 
 * Second hook only fires for logged-in users. If your action only allows Ajax requests to come from users not
 * logged-in, you need to instead use wp_ajax_nopriv_$action 
 */

function data_fetch(){

    $the_query = new WP_Query( array( 'posts_per_page' => -1, 's' => esc_attr( $_POST['keyword'] ), 'post_type' => array('post','courses') ) );
    if( $the_query->have_posts() ) :
        while( $the_query->have_posts() ): $the_query->the_post(); ?>

            <h2><a href="<?php echo esc_url( post_permalink() ); ?>"><?php the_title();?></a></h2>

        <?php endwhile;
        wp_reset_postdata();  
    endif;

    die();
}
/** End AJAX SEARCH **/

/* Replaces the excerpt (...) with "Read More" text by a link */
function new_excerpt_more($more) {
	global $post;
 return '<a href="'. get_permalink($post->ID) . '"> Read more </a></button>';
}
add_filter('excerpt_more', 'new_excerpt_more');

// To load parent function file in child theme
do_action('parent_loaded');
